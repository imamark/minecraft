/**
 * Head Bob & Sway - Minecraft Bedrock Edition
 * Dynamic first-person camera: head bob, sway, and context-aware movement/rotation.
 * Fully automatic: no commands needed. Just enable the pack in the world.
 *
 * Real first-person: the camera is locked to the player model's head (getHeadLocation).
 * To see your own body, legs, and armor when looking down, use a resource pack that
 * enables first-person body rendering (e.g. "First Person View" packs for Bedrock).
 */

import { world, system } from "@minecraft/server";

// --- Bob & sway (base) ---
const BOB_AMPLITUDE = 0.04;
const BOB_LATERAL_AMPLITUDE = 0.025;
const BOB_FREQUENCY = 0.15;
const BOB_SMOOTH = 0.12;
const SWAY_STRENGTH = 2.5;
const SWAY_SMOOTH = 0.15;

// --- Dynamic movement (context-aware) ---
const BOB_SPRINT_MULT = 1.4;        // Bob strength when sprinting
const BOB_CROUCH_MULT = 0.5;       // Bob strength when sneaking
const CROUCH_TILT_MULT = 0.45;     // Roll (strafe tilt) and movement lean when sneaking – same subdued feel as bob
const BOB_WATER_MULT = 0.7;        // Bob in water (slower, heavier feel)
const BOB_WATER_FREQ = 0.08;       // Slower cycle in water
const LANDING_DIP = 0.08;          // Vertical camera dip on landing (blocks)
const LANDING_DIP_RECOVERY = 0.08; // How fast landing dip recovers (0–1 per tick)
const FALL_DRIFT = 0.015;          // Slight camera drift when falling (per unit vel)
const JUMP_LIFT = 0.02;            // Tiny upward nudge when jumping
// --- Fall dive: pitch tilts down with falling speed for a more intense diving sensation ---
const FALL_DIVE_PITCH_MAX = 18;    // Max extra pitch (degrees down) at terminal fall speed
const FALL_DIVE_SPEED_REF = 8;    // Fall speed magnitude (blocks/s) at which we reach most of the effect
const FALL_DIVE_SMOOTH = 0.18;    // How fast dive pitch follows fall speed (0–1; higher = snappier)

// --- Dynamic rotation ---
const ROTATION_SMOOTH = 0.35;      // Camera rotation lag (0 = instant, higher = smoother follow)
const MOVEMENT_LEAN = 3;           // Degrees camera leans toward movement direction (yaw)
const MOVEMENT_LEAN_PITCH = 1.5;   // Slight pitch toward movement (e.g. looking ahead when moving)
const LANDING_PITCH_DIP = 4;       // Pitch dips down on landing (degrees)
const LANDING_PITCH_RECOVERY = 0.12;
// Default true for low-end devices (fewer updates, less tilt math). Set to false for full effects on stronger devices.
const PERFORMANCE_MODE = true;
const TICK_INTERVAL = PERFORMANCE_MODE ? 2 : 1;

// --- Camera collision & smooth transition ---
const CAMERA_CLIP_MARGIN = 0.08;   // Keep camera this far from walls (blocks)
const POSITION_SMOOTH = 0.35;      // How fast camera position follows target (0–1; higher = snappier)
const COLLISION_RAY_MAX = 3;       // Max distance to check for walls (blocks)

// --- Camera shake (explosions & impacts) ---
const SHAKE_DECAY = 0.15;          // How fast shake fades (0–1 per tick; higher = faster fade)
const SHAKE_POS_AMPLITUDE = 0.08; // Max position shake (blocks)
const SHAKE_ROT_AMPLITUDE = 3;    // Max rotation shake (degrees)
const SHAKE_FREQUENCY = 25;        // Shake oscillation speed (higher = faster shake)
const EXPLOSION_SHAKE_MULT = 2.5; // Explosions cause more shake
const FALL_DAMAGE_SHAKE_MULT = 1.8; // Fall damage causes more shake
const SHAKE_UPDATES_PER_TICK_MAX = 3; // Cap shake updates per player per tick (heavy combat: many hits → less lag)

// --- Idle breathing (realistic subtle up/down + slight lateral when standing still) ---
const IDLE_BREATH_ENABLED = true;   // Toggle idle breathing on/off
const IDLE_BREATH_VERTICAL = 0.005; // Up/down amplitude (blocks) – chest rise/fall, subtle
const IDLE_BREATH_LATERAL = 0.0015;// Slight lateral expansion on inhale (blocks) – very subtle
const IDLE_BREATH_SPEED = 0.078;   // ~4 s per breath at 20 tps (realistic resting rate)
const IDLE_TIME_THRESHOLD = 60;    // Ticks of no movement before breathing starts (3 seconds at 20tps)

// --- In-game config (world dynamic properties); use chat commands to change ---
const CONFIG_KEY_ENABLED = "headbob:enabled";
const CONFIG_KEY_REDUCED = "headbob:reduced_motion";
const REDUCED_MOTION_SCALE = 0.3;  // Scale all effects when reduced motion is on

// --- Collision optimization: skip raycast when ideal is very close to head ---
const COLLISION_SKIP_DIST = 0.06;

// --- Riding: reduce bob when on vehicle (horse, boat, minecart, etc.) ---
const RIDING_BOB_MULT = 0.2;

// --- Simulated roll (Bedrock API has no roll axis; we fake it with position bank + pitch/yaw tilt) ---
const ROLL_ENABLED = true;          // Set false to disable simulated roll
const ROLL_BANK_STRENGTH = 0.082;   // Lateral position offset when strafing (blocks) – "lean into turn" (higher = heavier)
const ROLL_TILT_STRENGTH = 9.5;     // Pitch/yaw combo to suggest horizon tilt (degrees) – higher = heavier tilt when turning
const ROLL_SMOOTH = 0.2;            // How fast roll follows strafe

// --- Elytra: gentle drift and pitch, minimal bob ---
const ELYTRA_BOB_MULT = 0;          // No walk bob while gliding
const ELYTRA_DRIFT = 0.012;         // Camera drift with velocity while gliding
const ELYTRA_PITCH_FOLLOW = 1.8;    // Pitch follows vertical velocity (nose up/down feel)
const ELYTRA_SMOOTH = 0.08;         // How fast elytra camera follows

// --- Performance: run collision raycast every N ticks instead of every tick ---
const COLLISION_RAYCAST_INTERVAL = PERFORMANCE_MODE ? 4 : 2;  // Higher in performance mode to save FPS

const playerState = new Map();

function getConfigEnabled() {
  const v = world.getDynamicProperty(CONFIG_KEY_ENABLED);
  return v === undefined ? true : !!v;
}

function getConfigReducedMotion() {
  const v = world.getDynamicProperty(CONFIG_KEY_REDUCED);
  return v === undefined ? false : !!v;
}

function getRightVector(viewDir) {
  const up = { x: 0, y: 1, z: 0 };
  const right = {
    x: up.y * viewDir.z - up.z * viewDir.y,
    y: up.z * viewDir.x - up.x * viewDir.z,
    z: up.x * viewDir.y - up.y * viewDir.x
  };
  const len = Math.sqrt(right.x * right.x + right.y * right.y + right.z * right.z);
  if (len < 1e-6) return { x: 1, y: 0, z: 0 };
  return { x: right.x / len, y: right.y / len, z: right.z / len };
}

function normalizeXZ(x, z) {
  const len = Math.sqrt(x * x + z * z);
  if (len < 1e-6) return { x: 0, z: 0 };
  return { x: x / len, z: z / len };
}

function clampAngle(angle) {
  while (angle > 180) angle -= 360;
  while (angle < -180) angle += 360;
  return angle;
}

function vec3Sub(a, b) {
  return { x: a.x - b.x, y: a.y - b.y, z: a.z - b.z };
}

function vec3Add(a, b) {
  return { x: a.x + b.x, y: a.y + b.y, z: a.z + b.z };
}

function vec3Scale(v, s) {
  return { x: v.x * s, y: v.y * s, z: v.z * s };
}

function vec3Length(v) {
  return Math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
}

/** Returns collision-safe camera position: from head toward ideal, stop at first block. */
function resolveCameraCollision(head, idealCam, dimension) {
  const dx = idealCam.x - head.x;
  const dy = idealCam.y - head.y;
  const dz = idealCam.z - head.z;
  const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
  if (dist < 1e-5) return { x: head.x, y: head.y, z: head.z };
  if (dist < COLLISION_SKIP_DIST) return idealCam;

  const dir = { x: dx / dist, y: dy / dist, z: dz / dist };
  const maxDist = Math.min(dist, COLLISION_RAY_MAX);

  let hit;
  try {
    hit = dimension.getBlockFromRay(head, dir, { maxDistance: maxDist });
  } catch (e) {
    return idealCam;
  }

  if (!hit || !hit.block) return idealCam;

  const block = hit.block;
  const faceLoc = hit.faceLocation ?? { x: 0.5, y: 0.5, z: 0.5 };
  const hitPoint = {
    x: block.x + faceLoc.x,
    y: block.y + faceLoc.y,
    z: block.z + faceLoc.z
  };
  const distToHit = vec3Length(vec3Sub(hitPoint, head));
  const safeDist = Math.max(0.05, distToHit - CAMERA_CLIP_MARGIN);

  return {
    x: head.x + dir.x * safeDist,
    y: head.y + dir.y * safeDist,
    z: head.z + dir.z * safeDist
  };
}

/**
 * @param { import("@minecraft/server").Player } player
 * @param {{ enabled?: boolean, reducedMotion?: boolean }} [optConfig] - Cached world config (avoids getDynamicProperty per player per tick in tick loop).
 */
function updateCamera(player, optConfig) {
  if (!player?.isValid || !player.camera?.isValid) return;

  const enabled = optConfig?.enabled !== undefined ? optConfig.enabled : getConfigEnabled();
  if (!enabled) {
    try { player.camera.clear(); } catch (e) {}
    return;
  }

  const reducedMotion = optConfig?.reducedMotion !== undefined ? optConfig.reducedMotion : getConfigReducedMotion();
  const motionScale = reducedMotion ? REDUCED_MOTION_SCALE : 1;

  const head = player.getHeadLocation();
  const rot = player.getRotation();
  const vel = player.getVelocity();
  const viewDir = player.getViewDirection();

  const horizontalSpeed = Math.sqrt(vel.x * vel.x + vel.z * vel.z);
  const isMoving = horizontalSpeed > 0.01;
  const isOnGround = player.isOnGround;
  const isSprinting = player.isSprinting;
  const isSneaking = player.isSneaking;
  const isInWater = player.isInWater;
  const isFalling = player.isFalling;
  const isClimbing = player.isClimbing;

  let isRiding = false;
  try {
    const riding = player.getComponent("minecraft:riding");
    isRiding = !!(riding && riding.entityRidingOn);
  } catch (e) {}

  let isGliding = false;
  try {
    if (typeof player.isGliding === "boolean") isGliding = player.isGliding;
  } catch (e) {}

  let state = playerState.get(player.id);
  if (!state) {
    state = {
      phase: 0, swayPitch: 0, swayYaw: 0, bobScale: 0,
      prevVelY: 0, prevOnGround: false,
      smoothPitch: rot.x, smoothYaw: rot.y,
      landingDip: 0, landingPitchDip: 0,
      shakeIntensity: 0, shakePhase: 0,
      idleTime: 0, idlePhase: 0,
      rollBank: 0, elytraPitch: 0, divePitch: 0,
      cachedSafeX: undefined, cachedSafeY: undefined, cachedSafeZ: undefined,
      lastHeadX: undefined, lastHeadY: undefined, lastHeadZ: undefined
    };
    playerState.set(player.id, state);
  }
  state._shakeUpdatesThisTick = 0; // Reset each tick so entityHurt can cap updates (heavy combat)

  // --- Landing detection (for dynamic dip) ---
  const justLanded = isOnGround && !state.prevOnGround && state.prevVelY < -0.2;
  if (justLanded) {
    const impact = Math.min(1, Math.abs(state.prevVelY) / 2);
    state.landingDip = LANDING_DIP * impact;
    state.landingPitchDip = LANDING_PITCH_DIP * impact;
  }
  state.prevVelY = vel.y;
  state.prevOnGround = isOnGround;

  // Recover from landing dip over time
  state.landingDip *= 1 - LANDING_DIP_RECOVERY;
  state.landingPitchDip *= 1 - LANDING_PITCH_RECOVERY;

  // --- Dynamic bob: scale by sprint / crouch / water / riding / elytra ---
  let moveMult = 1;
  let freqMult = 1;
  if (isRiding) moveMult *= RIDING_BOB_MULT;
  if (isGliding) moveMult *= ELYTRA_BOB_MULT;
  if (isSneaking) { moveMult *= BOB_CROUCH_MULT; freqMult *= 0.8; }
  if (isSprinting && isOnGround) moveMult *= BOB_SPRINT_MULT;
  if (isInWater) { moveMult *= BOB_WATER_MULT; freqMult = BOB_WATER_FREQ / BOB_FREQUENCY; }

  if (isOnGround && isMoving && !isClimbing && !isRiding && !isGliding) {
    state.phase += BOB_FREQUENCY * freqMult;
  }
  const phase = state.phase;

  const bobScale = isMoving && (isOnGround || isInWater) && !isRiding && !isGliding ? 1 : 0;
  state.bobScale = (state.bobScale ?? 0) * (1 - BOB_SMOOTH) + bobScale * BOB_SMOOTH;
  const vertBob = Math.sin(phase) * BOB_AMPLITUDE * state.bobScale * moveMult * motionScale;
  const latBob = Math.sin(phase + Math.PI / 2) * BOB_LATERAL_AMPLITUDE * state.bobScale * moveMult * motionScale;
  const right = getRightVector(viewDir);

  // --- Simulated roll (Bedrock has no camera roll; we use lateral bank + pitch/yaw to suggest tilt); skipped in PERFORMANCE_MODE ---
  const viewYawRad = PERFORMANCE_MODE ? 0 : (rot.y * Math.PI) / 180; // Avoid sin/cos when skipping roll
  let rollPosOffset = 0, rollTiltPitch = 0, rollTiltYaw = 0;
  const crouchTiltScale = isSneaking ? CROUCH_TILT_MULT : 1; // Reduce tilt when sneaking (like bob)
  if (!PERFORMANCE_MODE && ROLL_ENABLED && horizontalSpeed > 0.05 && !isRiding && !isGliding) {
    const rightVel = vel.x * Math.cos(viewYawRad) - vel.z * Math.sin(viewYawRad);
    const targetRollBank = Math.max(-1, Math.min(1, rightVel * 2.5));
    state.rollBank = (state.rollBank ?? 0) * (1 - ROLL_SMOOTH) + targetRollBank * ROLL_SMOOTH;
    const bank = Math.max(-1, Math.min(1, state.rollBank));
    rollPosOffset = bank * ROLL_BANK_STRENGTH * motionScale * crouchTiltScale;
    const tiltDeg = bank * ROLL_TILT_STRENGTH * motionScale * crouchTiltScale;
    rollTiltPitch = tiltDeg * Math.cos(viewYawRad);
    rollTiltYaw = -tiltDeg * Math.sin(viewYawRad);
  } else if (!PERFORMANCE_MODE && ROLL_ENABLED) {
    state.rollBank = (state.rollBank ?? 0) * (1 - ROLL_SMOOTH);
  }

  // --- Elytra: gentle drift and pitch follow ---
  let elytraDriftX = 0, elytraDriftY = 0, elytraDriftZ = 0;
  let elytraPitch = 0;
  if (isGliding) {
    const rawElytraPitch = (state.elytraPitch ?? 0) * (1 - ELYTRA_SMOOTH) + vel.y * ELYTRA_PITCH_FOLLOW * motionScale * ELYTRA_SMOOTH;
    state.elytraPitch = Math.max(-12, Math.min(12, rawElytraPitch));
    elytraPitch = state.elytraPitch;
    elytraDriftX = vel.x * ELYTRA_DRIFT * motionScale;
    elytraDriftY = vel.y * ELYTRA_DRIFT * motionScale;
    elytraDriftZ = vel.z * ELYTRA_DRIFT * motionScale;
  } else {
    state.elytraPitch = (state.elytraPitch ?? 0) * 0.85;
  }

  // --- Fall dive: pitch tilts down with falling speed (diving sensation); only when free-falling ---
  let divePitch = 0;
  if (isFalling && vel.y < 0 && !isGliding && !isRiding) {
    const fallSpeed = Math.abs(vel.y);
    const targetDivePitch = Math.min(FALL_DIVE_PITCH_MAX, (fallSpeed / FALL_DIVE_SPEED_REF) * FALL_DIVE_PITCH_MAX) * motionScale;
    state.divePitch = (state.divePitch ?? 0) * (1 - FALL_DIVE_SMOOTH) + targetDivePitch * FALL_DIVE_SMOOTH;
    divePitch = state.divePitch;
  } else {
    state.divePitch = (state.divePitch ?? 0) * (1 - FALL_DIVE_SMOOTH);
    divePitch = state.divePitch;
  }

  // --- Dynamic position: landing dip, jump lift, fall drift ---
  let dynY = -state.landingDip * motionScale;
  if (!isOnGround && vel.y > 0.1 && !isGliding) dynY += JUMP_LIFT * motionScale;
  if (isFalling && vel.y < 0 && !isGliding) dynY += vel.y * FALL_DRIFT * motionScale;

  // --- Camera shake (decay over time); fewer sin/cos in PERFORMANCE_MODE ---
  state.shakeIntensity *= 1 - SHAKE_DECAY;
  state.shakePhase += SHAKE_FREQUENCY * 0.1;
  const shakeAmpPos = SHAKE_POS_AMPLITUDE * state.shakeIntensity * motionScale;
  const shakeAmpRot = SHAKE_ROT_AMPLITUDE * state.shakeIntensity * motionScale;
  const s = Math.sin(state.shakePhase);
  const c = Math.cos(state.shakePhase);
  const shakeX = s * shakeAmpPos;
  const shakeY = (PERFORMANCE_MODE ? s : Math.sin(state.shakePhase * 1.3 + 0.5)) * shakeAmpPos;
  const shakeZ = (PERFORMANCE_MODE ? c : Math.cos(state.shakePhase * 0.9)) * shakeAmpPos;
  const shakeRotX = (PERFORMANCE_MODE ? s : Math.sin(state.shakePhase * 1.1)) * shakeAmpRot;
  const shakeRotY = (PERFORMANCE_MODE ? c : Math.cos(state.shakePhase * 0.8 + 1.2)) * shakeAmpRot;

  // --- Idle breathing (realistic: slow vertical + tiny lateral when standing still); no rotation ---
  let idleSwayX = 0, idleSwayY = 0, idleSwayZ = 0;
  let idleSwayRotX = 0, idleSwayRotY = 0;
  if (!PERFORMANCE_MODE && IDLE_BREATH_ENABLED && !isRiding && !isGliding) {
    if (!isMoving && isOnGround) {
      state.idleTime++;
      if (state.idleTime > IDLE_TIME_THRESHOLD) {
        if (state.idleTime === IDLE_TIME_THRESHOLD + 1) state.idlePhase = 0;
        state.idlePhase += IDLE_BREATH_SPEED;
        const breath = Math.sin(state.idlePhase); // One cycle = one breath (inhale up, exhale down)
        idleSwayY = breath * IDLE_BREATH_VERTICAL * motionScale;
        idleSwayX = breath * IDLE_BREATH_LATERAL * right.x * motionScale;
        idleSwayZ = breath * IDLE_BREATH_LATERAL * right.z * motionScale;
      }
    } else {
      state.idleTime = 0;
      state.idlePhase *= 0.97; // Gentle fade when moving
    }
  }

  let idealX = head.x + right.x * (latBob + rollPosOffset) + shakeX + idleSwayX + elytraDriftX;
  let idealY = head.y + vertBob + dynY + shakeY + idleSwayY + elytraDriftY;
  let idealZ = head.z + right.z * (latBob + rollPosOffset) + shakeZ + idleSwayZ + elytraDriftZ;

  // --- Camera collision: pull back if camera would clip (raycast every N ticks to save cost) ---
  const idealCam = { x: idealX, y: idealY, z: idealZ };
  const headMoved = state.lastHeadX !== undefined && (
    Math.abs(head.x - state.lastHeadX) > 2 || Math.abs(head.y - state.lastHeadY) > 2 || Math.abs(head.z - state.lastHeadZ) > 2
  );
  if (headMoved) {
    state.cachedSafeX = undefined;
    state.cachedSafeY = undefined;
    state.cachedSafeZ = undefined;
  }
  state.lastHeadX = head.x;
  state.lastHeadY = head.y;
  state.lastHeadZ = head.z;
  const tickMod = (system.currentTick + (player.id?.length ?? 0)) % COLLISION_RAYCAST_INTERVAL;
  const needRaycast = tickMod === 0 || state.cachedSafeX === undefined;
  if (needRaycast) {
    const safeCam = resolveCameraCollision(head, idealCam, player.dimension);
    state.cachedSafeX = safeCam.x;
    state.cachedSafeY = safeCam.y;
    state.cachedSafeZ = safeCam.z;
  }
  if (state.cachedSafeX !== undefined && state.cachedSafeY !== undefined && state.cachedSafeZ !== undefined) {
    idealX = state.cachedSafeX;
    idealY = state.cachedSafeY;
    idealZ = state.cachedSafeZ;
  }

  // --- Smooth position transition (avoid snapping when entering/leaving walls) ---
  if (state.smoothCamX === undefined) {
    state.smoothCamX = idealX;
    state.smoothCamY = idealY;
    state.smoothCamZ = idealZ;
  }
  state.smoothCamX += (idealX - state.smoothCamX) * POSITION_SMOOTH;
  state.smoothCamY += (idealY - state.smoothCamY) * POSITION_SMOOTH;
  state.smoothCamZ += (idealZ - state.smoothCamZ) * POSITION_SMOOTH;

  const camX = state.smoothCamX;
  const camY = state.smoothCamY;
  const camZ = state.smoothCamZ;

  // --- Sway (velocity-based rotation) ---
  const targetSwayYaw = -vel.x * SWAY_STRENGTH * motionScale;
  const targetSwayPitch = vel.y * SWAY_STRENGTH * 0.5 * motionScale;
  state.swayYaw = state.swayYaw * (1 - SWAY_SMOOTH) + targetSwayYaw * SWAY_SMOOTH;
  state.swayPitch = state.swayPitch * (1 - SWAY_SMOOTH) + targetSwayPitch * SWAY_SMOOTH;

  // --- Dynamic rotation: smooth follow + movement lean + landing pitch ---
  state.smoothPitch = state.smoothPitch + (rot.x - state.smoothPitch) * (1 - ROTATION_SMOOTH);
  state.smoothYaw = state.smoothYaw + clampAngle(rot.y - state.smoothYaw) * (1 - ROTATION_SMOOTH);
  // Keep smoothYaw in [-180, 180] so it doesn't drift and cause a snap when passed to the camera
  if (state.smoothYaw > 180) state.smoothYaw -= 360;
  if (state.smoothYaw < -180) state.smoothYaw += 360;

  let leanYaw = 0, leanPitch = 0;
  if (!PERFORMANCE_MODE && horizontalSpeed > 0.05 && !isRiding) {
    const moveDir = normalizeXZ(vel.x, vel.z);
    const viewYawRad = (rot.y * Math.PI) / 180;
    const viewX = -Math.sin(viewYawRad), viewZ = -Math.cos(viewYawRad);
    const dot = moveDir.x * viewX + moveDir.z * viewZ;
    const cross = moveDir.x * viewZ - moveDir.z * viewX;
    const leanScale = motionScale * (isSneaking ? CROUCH_TILT_MULT : 1);
    leanYaw = cross * MOVEMENT_LEAN * leanScale;
    leanPitch = (dot - 1) * MOVEMENT_LEAN_PITCH * leanScale;
  }

  const landingPitchScaled = state.landingPitchDip * motionScale;
  const camPitch = Math.max(-90, Math.min(90,
    state.smoothPitch + state.swayPitch - landingPitchScaled + leanPitch + shakeRotX + idleSwayRotX + rollTiltPitch + elytraPitch + divePitch
  ));
  let camYaw = state.smoothYaw + state.swayYaw + leanYaw + shakeRotY + idleSwayRotY + rollTiltYaw;
  camYaw = clampAngle(camYaw); // Keep in [-180, 180] so the engine doesn't snap on wrap

  try {
    player.camera.setCamera("minecraft:free", {
      location: { x: camX, y: camY, z: camZ },
      rotation: { x: camPitch, y: camYaw }
    });
  } catch (e) {}
}

function makeInitialState(player) {
  const rot = player?.getRotation?.() ?? { x: 0, y: 0 };
  return {
    phase: 0, swayPitch: 0, swayYaw: 0, bobScale: 0,
    prevVelY: 0, prevOnGround: true,
    smoothPitch: rot.x, smoothYaw: rot.y,
    landingDip: 0, landingPitchDip: 0,
    shakeIntensity: 0, shakePhase: 0,
    idleTime: 0, idlePhase: 0,
    rollBank: 0, elytraPitch: 0, divePitch: 0,
    cachedSafeX: undefined, cachedSafeY: undefined, cachedSafeZ: undefined,
    lastHeadX: undefined, lastHeadY: undefined, lastHeadZ: undefined
  };
}

function onPlayerSpawn(event) {
  const player = event.player;
  if (player?.isValid && player.camera?.isValid) {
    playerState.set(player.id, makeInitialState(player));
    updateCamera(player);
  }
}

function tick() {
  // Cache world config once per tick to avoid 2× getDynamicProperty per player (reduces lag with many players / heavy combat).
  const config = { enabled: getConfigEnabled(), reducedMotion: getConfigReducedMotion() };
  const currentPlayerIds = new Set();
  for (const player of world.getPlayers()) {
    currentPlayerIds.add(player.id);
    try {
      updateCamera(player, config);
    } catch (err) {
      // One player error (e.g. invalid dimension) shouldn't break the loop
    }
  }
  // Prune state for players no longer in the world (fallback when beforeEvents.playerLeave isn't available)
  for (const id of playerState.keys()) {
    if (!currentPlayerIds.has(id)) playerState.delete(id);
  }
}

// --- Damage/impact event handler (triggers camera shake) ---
function getShakeMultiplier(cause) {
  if (!cause) return 1;
  const c = String(cause);
  if (c === "entityExplosion" || c === "blockExplosion" || c === "explosion") return EXPLOSION_SHAKE_MULT;
  if (c === "fall") return FALL_DAMAGE_SHAKE_MULT;
  if (c === "projectile" || c === "entityAttack" || c === "anvil" || c === "fallingBlock") return 1.2;
  return 1;
}

// Fires for every hurt entity (players + mobs). Exit fast for non-players to reduce lag in heavy combat.
function onEntityHurt(event) {
  const entity = event.hurtEntity;
  if (!entity?.isValid) return;
  if (entity.typeId !== "minecraft:player") return;

  const player = entity;
  let state = playerState.get(player.id);
  if (!state) {
    playerState.set(player.id, makeInitialState(player));
    state = playerState.get(player.id);
  }
  if (!state) return;

  // Cap shake updates per player per tick so many simultaneous hits don't cost extra (reset in updateCamera).
  state._shakeUpdatesThisTick = (state._shakeUpdatesThisTick || 0) + 1;
  if (state._shakeUpdatesThisTick > SHAKE_UPDATES_PER_TICK_MAX) return;

  const damage = event.damage;
  const cause = event.damageSource?.cause;
  const shakeMult = getShakeMultiplier(cause);
  const shakeAmount = Math.min(1, damage / 10) * shakeMult;
  state.shakeIntensity = Math.min(1, state.shakeIntensity + shakeAmount);
}

// --- In-game toggles via chat (cancel message so command doesn't show) ---
function onChatSend(event) {
  const msg = (event.message || "").trim().toLowerCase();
  if (!msg.startsWith("/headbob")) return;

  event.cancel = true;
  const player = event.sender;
  const parts = msg.split(/\s+/);
  const cmd = parts[1];

  try {
    if (cmd === "off" || cmd === "disable") {
      world.setDynamicProperty(CONFIG_KEY_ENABLED, false);
      player.runCommand("tellraw @s {\"text\":\"Head Bob & Sway disabled. Use F5 for third-person. Type /headbob on to re-enable.\",\"color\":\"gray\"}");
    } else if (cmd === "on" || cmd === "enable") {
      world.setDynamicProperty(CONFIG_KEY_ENABLED, true);
      player.runCommand("tellraw @s {\"text\":\"Head Bob & Sway enabled.\",\"color\":\"gray\"}");
    } else if (cmd === "reduced" || cmd === "low") {
      world.setDynamicProperty(CONFIG_KEY_REDUCED, true);
      player.runCommand("tellraw @s {\"text\":\"Reduced motion mode on. All camera effects scaled down.\",\"color\":\"gray\"}");
    } else if (cmd === "full" || cmd === "normal") {
      world.setDynamicProperty(CONFIG_KEY_REDUCED, false);
      player.runCommand("tellraw @s {\"text\":\"Full motion mode.\",\"color\":\"gray\"}");
    } else if (!cmd || cmd === "status" || cmd === "?") {
      const on = getConfigEnabled();
      const reduced = getConfigReducedMotion();
      const statusText = "Head Bob: " + (on ? "on" : "off") + ", Motion: " + (reduced ? "reduced" : "full");
      player.runCommand("tellraw @s {\"text\":\"" + statusText.replace(/"/g, '\\"') + "\",\"color\":\"gray\"}");
    } else {
      player.runCommand("tellraw @s {\"text\":\"Head Bob: /headbob on | off | reduced | full | status (or /headbob alone for status)\",\"color\":\"yellow\"}");
    }
  } catch (e) {}
}

function onPlayerLeave(event) {
  if (event.player?.id) playerState.delete(event.player.id);
}

// Apply camera when a player spawns (join or respawn)
world.afterEvents.playerSpawn.subscribe(onPlayerSpawn);

// Listen for damage events to trigger camera shake
world.afterEvents.entityHurt.subscribe(onEntityHurt);

// In-game toggles: /headbob on | off | reduced | full (only when this API exists)
if (world.beforeEvents?.chatSend) world.beforeEvents.chatSend.subscribe(onChatSend);

// Clean up state when player leaves; tick() also prunes stale state when this API isn't available
if (world.beforeEvents?.playerLeave) world.beforeEvents.playerLeave.subscribe(onPlayerLeave);

// Update camera every N ticks for all players (keeps bob/sway in sync)
system.runInterval(tick, TICK_INTERVAL);

// Apply immediately to any players already in the world when the pack loads (no command needed)
system.runTimeout(() => {
  for (const player of world.getPlayers()) {
    if (player?.isValid && player.camera?.isValid) {
      playerState.set(player.id, makeInitialState(player));
      updateCamera(player);
    }
  }
}, 1);
