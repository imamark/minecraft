/**
 * Camera Overhaul - Dramatic movement (head bob + sway) while walking
 * Runs every tick and applies a first-person-style camera with bobbing and sway.
 */

import { world, system } from '@minecraft/server';

const PRESET = 'camera_overhaul:first_person_dramatic';

// Tune these for feel (stronger = more dramatic)
const BOB_AMPLITUDE = 0.12;        // blocks, vertical bob
const BOB_AMPLITUDE_H = 0.06;      // blocks, horizontal wobble
const BOB_SPEED = 0.25;            // radians per tick
const SWAY_DEGREES = 4;            // max rotation sway (degrees)
const VELOCITY_SCALE = 8;          // how much velocity affects bob amplitude
const SPRINT_MULTIPLIER = 1.4;     // extra bob when sprinting

// Smoothing (0 = no smoothing, higher = slower decay)
const SWAY_SMOOTH = 0.92;
const BOB_SMOOTH = 0.95;

// Per-player state for smoothing
const playerState = new Map();

function getOrCreateState(player) {
  let state = playerState.get(player.id);
  if (!state) {
    state = {
      velX: 0, velZ: 0,
      swayX: 0, swayY: 0,
      bobPhase: 0,
      lastY: null
    };
    playerState.set(player.id, state);
  }
  return state;
}

function tick() {
  const tickCount = system.currentTick;
  const players = world.getPlayers();

  for (const player of players) {
    if (!player?.camera?.isValid) continue;
    // Skip if player has opted out via tag
    if (player.hasTag('no_dramatic_camera')) continue;

    const loc = player.getHeadLocation();
    const rot = player.getRotation();
    const vel = player.getVelocity();
    const onGround = player.isOnGround;
    const sprinting = player.isSprinting ?? false;

    const state = getOrCreateState(player);

    // Horizontal speed for bob intensity
    const hSpeed = Math.sqrt(vel.x * vel.x + vel.z * vel.z);
    const moving = onGround && hSpeed > 0.02;
    const mult = sprinting ? SPRINT_MULTIPLIER : 1;

    // Advance bob phase when moving
    if (moving) {
      state.bobPhase += BOB_SPEED * (1 + Math.min(hSpeed * VELOCITY_SCALE, 1.5)) * mult;
    } else {
      state.bobPhase *= BOB_SMOOTH;
    }

    // Bob offset (world space: up/down and small horizontal wobble)
    const bobV = moving ? Math.sin(state.bobPhase) * BOB_AMPLITUDE * Math.min(hSpeed * VELOCITY_SCALE, 1) * mult : 0;
    const bobH1 = moving ? Math.cos(state.bobPhase * 0.7) * BOB_AMPLITUDE_H * Math.min(hSpeed * VELOCITY_SCALE, 1) * mult : 0;
    const bobH2 = moving ? Math.sin(state.bobPhase * 0.5 + 1) * BOB_AMPLITUDE_H * 0.7 * Math.min(hSpeed * VELOCITY_SCALE, 1) * mult : 0;

    // Sway from velocity (lean into movement)
    const targetSwayX = moving ? -vel.z * SWAY_DEGREES * 2 : 0;
    const targetSwayY = moving ? vel.x * SWAY_DEGREES * 2 : 0;
    state.swayX = state.swayX * SWAY_SMOOTH + targetSwayX * (1 - SWAY_SMOOTH);
    state.swayY = state.swayY * SWAY_SMOOTH + targetSwayY * (1 - SWAY_SMOOTH);

    // Clamp sway
    const swayX = Math.max(-SWAY_DEGREES, Math.min(SWAY_DEGREES, state.swayX));
    const swayY = Math.max(-SWAY_DEGREES, Math.min(SWAY_DEGREES, state.swayY));

    const camX = loc.x + bobH1;
    const camY = loc.y + bobV;
    const camZ = loc.z + bobH2;

    // Rotation: player view + sway (rot.x = pitch, rot.y = yaw in Bedrock)
    const pitch = Math.max(-90, Math.min(90, rot.x + swayX));
    const yaw = rot.y + swayY;

    try {
      player.camera.setCamera(PRESET, {
        location: { x: camX, y: camY, z: camZ },
        rotation: { x: pitch, y: yaw }
      });
    } catch (e) {
      // Ignore if preset not loaded or camera in invalid state
    }
  }

  // Clean up state for players who left
  const ids = new Set(players.map(p => p.id));
  for (const id of playerState.keys()) {
    if (!ids.has(id)) playerState.delete(id);
  }
}

function applyDramaticCamera(player) {
  if (!player?.camera?.isValid || player.hasTag('no_dramatic_camera')) return;
  try {
    player.camera.setCamera(PRESET, {
      location: player.getHeadLocation(),
      rotation: player.getRotation()
    });
  } catch (e) {}
}

// Apply to all players as soon as the world/script loads (no commands needed)
system.runTimeout(() => {
  for (const player of world.getPlayers()) {
    applyDramaticCamera(player);
  }
}, 1);

// Apply on every spawn: first join, respawn after death, dimension change, etc.
world.afterEvents.playerSpawn.subscribe(({ player }) => {
  applyDramaticCamera(player);
});

// Run every tick to update bob and sway
system.runInterval(tick, 1);
